var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send/route.js")
R.c("server/chunks/node_modules_0c1cd6a8._.js")
R.c("server/chunks/[root-of-the-server]__50635773._.js")
R.c("server/chunks/_next-internal_server_app_api_send_route_actions_8fbd336a.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/send/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/send/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
