(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_e4a73afb._.js",
  "static/chunks/_a9973b33._.js"
],
    source: "dynamic"
});
