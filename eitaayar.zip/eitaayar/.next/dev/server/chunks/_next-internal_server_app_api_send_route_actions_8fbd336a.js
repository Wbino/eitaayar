module.exports = [
"[project]/.next-internal/server/app/api/send/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_send_route_actions_8fbd336a.js.map